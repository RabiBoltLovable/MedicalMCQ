import { create } from 'zustand';
import type { AuthState, User } from '../types/User';

// Simulated user database
const USERS: Record<string, { password: string; user: User }> = {};

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  isAuthenticated: false,

  login: async (email: string, password: string) => {
    const userRecord = USERS[email];
    
    if (!userRecord || userRecord.password !== password) {
      throw new Error('Invalid credentials');
    }

    set({ user: userRecord.user, isAuthenticated: true });
  },

  signup: async (name: string, email: string, password: string) => {
    if (USERS[email]) {
      throw new Error('User already exists');
    }

    const newUser: User = {
      id: crypto.randomUUID(),
      email,
      name,
    };

    USERS[email] = { password, user: newUser };
    set({ user: newUser, isAuthenticated: true });
  },

  logout: () => {
    set({ user: null, isAuthenticated: false });
  },
}));