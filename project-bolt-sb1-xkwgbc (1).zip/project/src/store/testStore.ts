import { create } from 'zustand';
import type { Question, QuestionState } from '../types/Question';
import type { TestResult } from '../types/MockTest';

interface TestStore {
  questions: Question[];
  answers: Record<number, string>;
  showResults: boolean;
  testResult: TestResult | null;
  setQuestions: (questions: Question[]) => void;
  setAnswer: (index: number, answer: string) => void;
  submitTest: () => void;
  resetTest: () => void;
}

export const useTestStore = create<TestStore>((set, get) => ({
  questions: [],
  answers: {},
  showResults: false,
  testResult: null,

  setQuestions: (questions) => set({ questions }),

  setAnswer: (index, answer) => 
    set((state) => ({
      answers: { ...state.answers, [index]: answer }
    })),

  submitTest: () => {
    const { questions, answers } = get();
    const totalQuestions = questions.length;
    const correctAnswers = questions.reduce((count, question, index) => {
      return count + (answers[index] === question.correct_answer ? 1 : 0);
    }, 0);

    const testResult: TestResult = {
      testId: '1', // In a real app, this would come from the current test
      score: (correctAnswers / totalQuestions) * 100,
      totalQuestions,
      correctAnswers,
      wrongAnswers: totalQuestions - correctAnswers,
      timeTaken: 0, // In a real app, track actual time
    };

    set({ showResults: true, testResult });
  },

  resetTest: () => set({
    answers: {},
    showResults: false,
    testResult: null,
  }),
}));